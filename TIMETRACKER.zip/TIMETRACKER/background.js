let currentTabId = null;
let currentTabUrl = null;
let startTime = null;

function updateTimeSpent() {
  if (currentTabId && currentTabUrl && startTime) {
    const endTime = new Date();
    const timeSpent = endTime - startTime;
    
    chrome.storage.local.get(['timeData'], function(result) {
      let timeData = result.timeData || {};
      const date = new Date().toISOString().split('T')[0];
      const week = getWeekNumber(new Date());
      const month = new Date().toISOString().slice(0, 7);

      if (!timeData[currentTabUrl]) {
        timeData[currentTabUrl] = { daily: {}, weekly: {}, monthly: {} };
      }

      timeData[currentTabUrl].daily[date] = (timeData[currentTabUrl].daily[date] || 0) + timeSpent;
      timeData[currentTabUrl].weekly[week] = (timeData[currentTabUrl].weekly[week] || 0) + timeSpent;
      timeData[currentTabUrl].monthly[month] = (timeData[currentTabUrl].monthly[month] || 0) + timeSpent;

      chrome.storage.local.set({timeData: timeData});
    });

    startTime = endTime;
  }
}

function getWeekNumber(d) {
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return d.getUTCFullYear() + '-W' + weekNo;
}

chrome.tabs.onActivated.addListener(function(activeInfo) {
  updateTimeSpent();
  currentTabId = activeInfo.tabId;
  chrome.tabs.get(currentTabId, function(tab) {
    currentTabUrl = new URL(tab.url).hostname;
    startTime = new Date();
  });
});

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (tabId === currentTabId && changeInfo.url) {
    updateTimeSpent();
    currentTabUrl = new URL(changeInfo.url).hostname;
    startTime = new Date();
  }
});

setInterval(updateTimeSpent, 1000);