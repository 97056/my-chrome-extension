let currentView = 'daily';

function formatTime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  return `${hours.toString().padStart(2, '0')}:${(minutes % 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
}

function displayTimeData() {
  chrome.storage.local.get(['timeData'], function(result) {
    const timeData = result.timeData || {};
    const today = new Date().toISOString().split('T')[0];
    const currentWeek = getWeekNumber(new Date());
    const currentMonth = new Date().toISOString().slice(0, 7);

    let html = '<ul>';
    for (const url in timeData) {
      let time;
      if (currentView === 'daily') {
        time = timeData[url].daily[today] || 0;
      } else if (currentView === 'weekly') {
        time = timeData[url].weekly[currentWeek] || 0;
      } else {
        time = timeData[url].monthly[currentMonth] || 0;
      }

      html += `
        <li>
          <img src="https://www.google.com/s2/favicons?domain=${url}" class="favicon" alt="Favicon">
          <span class="website-name">${url}</span>
          <span class="time">${formatTime(time)}</span>
        </li>
      `;
    }
    html += '</ul>';

    document.getElementById('timeData').innerHTML = html;
  });
}

function getWeekNumber(d) {
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return d.getUTCFullYear() + '-W' + weekNo;
}

function updateActiveButton() {
  document.querySelectorAll('.toggle-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.getElementById(`${currentView}Btn`).classList.add('active');
}

document.addEventListener('DOMContentLoaded', function() {
  displayTimeData();
  setInterval(displayTimeData, 1000);  // Update every second

  document.getElementById('dailyBtn').addEventListener('click', function() {
    currentView = 'daily';
    updateActiveButton();
    displayTimeData();
  });

  document.getElementById('weeklyBtn').addEventListener('click', function() {
    currentView = 'weekly';
    updateActiveButton();
    displayTimeData();
  });

  document.getElementById('monthlyBtn').addEventListener('click', function() {
    currentView = 'monthly';
    updateActiveButton();
    displayTimeData();
  });
});